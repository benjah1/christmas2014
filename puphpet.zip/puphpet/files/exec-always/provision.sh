#!/bin/bash


cd /var/www/gobenja/

# ln -sf /vagrant/Gruntfile.js Gruntfile.js
# ln -sf /vagrant/package.json package.json
# ln -sf /vagrant/bower.json bower.json
# ln -sf /vagrant/.bowerrc .bowerrc

if [[ -d /var/www/gobenja/app ]]; then
	rm /var/www/gobenja/app -R
fi
ln -sf /vagrant/app app

if [[ -d /var/www/gobenja/www ]]; then
	rm /var/www/gobenja/www -R
fi
ln -sf /vagrant/www www

if [[ -d /var/www/gobenja/test ]]; then
	rm /var/www/gobenja/test -R
fi

ln -sf /vagrant/test test

# chown vagrant:www-data -R /var/www/gobenja
